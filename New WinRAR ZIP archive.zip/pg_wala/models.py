from flask_sqlalchemy import SQLAlchemy
from datetime import datetime

db = SQLAlchemy()

class Room(db.Model):
    __tablename__ = 'rooms'
    room_no   = db.Column(db.Integer, primary_key=True)
    room_type = db.Column(db.String(10), default='Non-AC')   # AC / Non-AC
    capacity  = db.Column(db.Integer, default=2)
    floor     = db.Column(db.Integer, default=0)
    beds      = db.relationship('Bed', backref='room', lazy=True, cascade='all, delete-orphan')

class Bed(db.Model):
    __tablename__ = 'beds'
    bed_id    = db.Column(db.Integer, primary_key=True)
    room_no   = db.Column(db.Integer, db.ForeignKey('rooms.room_no'), nullable=False)
    is_occupied = db.Column(db.Boolean, default=False)
    guest     = db.relationship('Guest', backref='bed', uselist=False)

class Guest(db.Model):
    __tablename__ = 'guests'
    guest_id     = db.Column(db.Integer, primary_key=True)
    name         = db.Column(db.String(100), nullable=False)
    contact_info = db.Column(db.String(20))
    id_proof     = db.Column(db.String(100))
    bed_id       = db.Column(db.Integer, db.ForeignKey('beds.bed_id'), nullable=True)
    joined_on    = db.Column(db.DateTime, default=datetime.utcnow)
    is_active    = db.Column(db.Boolean, default=True)

class Complaint(db.Model):
    __tablename__ = 'complaints'
    complaint_id = db.Column(db.Integer, primary_key=True)
    description  = db.Column(db.Text, nullable=False)
    status       = db.Column(db.String(20), default='New')   # New / In Progress / Resolved
    date_logged  = db.Column(db.DateTime, default=datetime.utcnow)
    guest_id     = db.Column(db.Integer, db.ForeignKey('guests.guest_id'), nullable=True)
    guest        = db.relationship('Guest', backref='complaints')
    