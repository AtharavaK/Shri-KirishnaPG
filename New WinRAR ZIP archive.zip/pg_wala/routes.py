from flask import render_template, request, redirect, url_for, jsonify, flash
from models import db, Guest, Complaint, Room, Bed
from datetime import datetime

def configure_routes(app):

    # ─── Dashboard ────────────────────────────────────────────────────────────
    @app.route('/')
    def index():
        total_guests     = Guest.query.filter_by(is_active=True).count()
        total_beds       = Bed.query.count()
        occupied_beds    = Bed.query.filter_by(is_occupied=True).count()
        vacant_beds      = total_beds - occupied_beds
        open_complaints  = Complaint.query.filter(Complaint.status != 'Resolved').count()
        recent_complaints = Complaint.query.order_by(Complaint.date_logged.desc()).limit(5).all()
        recent_guests    = Guest.query.filter_by(is_active=True).order_by(Guest.joined_on.desc()).limit(5).all()
        return render_template('index.html',
            total_guests=total_guests, total_beds=total_beds,
            occupied_beds=occupied_beds, vacant_beds=vacant_beds,
            open_complaints=open_complaints,
            recent_complaints=recent_complaints,
            recent_guests=recent_guests)

    # ─── Guests ───────────────────────────────────────────────────────────────
    @app.route('/guests', methods=['GET', 'POST'])
    def manage_guests():
        if request.method == 'POST':
            bed_id = request.form.get('bed_id') or None
            guest = Guest(
                name=request.form['name'],
                contact_info=request.form['contact'],
                id_proof=request.form['id_proof'],
                bed_id=int(bed_id) if bed_id else None
            )
            db.session.add(guest)
            if bed_id:
                bed = Bed.query.get(int(bed_id))
                if bed:
                    bed.is_occupied = True
            db.session.commit()
            flash('Guest registered successfully!', 'success')
            return redirect(url_for('manage_guests'))

        guests = Guest.query.filter_by(is_active=True).order_by(Guest.joined_on.desc()).all()
        vacant_beds = Bed.query.filter_by(is_occupied=False).all()
        return render_template('guests.html', guests=guests, vacant_beds=vacant_beds)

    @app.route('/guests/edit/<int:guest_id>', methods=['GET', 'POST'])
    def edit_guest(guest_id):
        guest = Guest.query.get_or_404(guest_id)
        if request.method == 'POST':
            guest.name         = request.form['name']
            guest.contact_info = request.form['contact']
            guest.id_proof     = request.form['id_proof']
            db.session.commit()
            flash('Guest updated.', 'success')
            return redirect(url_for('manage_guests'))
        vacant_beds = Bed.query.filter_by(is_occupied=False).all()
        return render_template('edit_guest.html', guest=guest, vacant_beds=vacant_beds)

    @app.route('/guests/delete/<int:guest_id>', methods=['POST'])
    def delete_guest(guest_id):
        guest = Guest.query.get_or_404(guest_id)
        if guest.bed_id:
            bed = Bed.query.get(guest.bed_id)
            if bed:
                bed.is_occupied = False
        guest.is_active = False
        db.session.commit()
        flash('Guest checked out.', 'info')
        return redirect(url_for('manage_guests'))

    # ─── Complaints ───────────────────────────────────────────────────────────
    @app.route('/complaints', methods=['GET', 'POST'])
    def manage_complaints():
        if request.method == 'POST':
            c = Complaint(
                description=request.form['description'],
                guest_id=request.form.get('guest_id') or None
            )
            db.session.add(c)
            db.session.commit()
            flash('Complaint filed.', 'success')
            return redirect(url_for('manage_complaints'))

        status_filter = request.args.get('status', 'all')
        q = Complaint.query
        if status_filter != 'all':
            q = q.filter_by(status=status_filter)
        complaints = q.order_by(Complaint.date_logged.desc()).all()
        active_guests = Guest.query.filter_by(is_active=True).all()
        return render_template('complaints.html',
            complaints=complaints, status_filter=status_filter,
            active_guests=active_guests)

    @app.route('/complaints/update/<int:complaint_id>', methods=['POST'])
    def update_complaint(complaint_id):
        c = Complaint.query.get_or_404(complaint_id)
        c.status = request.form['status']
        db.session.commit()
        flash('Status updated.', 'success')
        return redirect(url_for('manage_complaints'))

    @app.route('/complaints/delete/<int:complaint_id>', methods=['POST'])
    def delete_complaint(complaint_id):
        c = Complaint.query.get_or_404(complaint_id)
        db.session.delete(c)
        db.session.commit()
        flash('Complaint removed.', 'info')
        return redirect(url_for('manage_complaints'))

    # ─── Rooms ────────────────────────────────────────────────────────────────
    @app.route('/rooms', methods=['GET', 'POST'])
    def manage_rooms():
        if request.method == 'POST':
            room = Room(
                room_no=int(request.form['room_no']),
                room_type=request.form['room_type'],
                capacity=int(request.form['capacity']),
                floor=int(request.form['floor'])
            )
            db.session.add(room)
            db.session.flush()
            for i in range(room.capacity):
                db.session.add(Bed(room_no=room.room_no))
            db.session.commit()
            flash(f'Room {room.room_no} added with {room.capacity} beds.', 'success')
            return redirect(url_for('manage_rooms'))

        rooms = Room.query.order_by(Room.floor, Room.room_no).all()
        return render_template('rooms.html', rooms=rooms)

    @app.route('/rooms/delete/<int:room_no>', methods=['POST'])
    def delete_room(room_no):
        room = Room.query.get_or_404(room_no)
        db.session.delete(room)
        db.session.commit()
        flash('Room deleted.', 'info')
        return redirect(url_for('manage_rooms'))

    # ─── API: stats for live dashboard ────────────────────────────────────────
    @app.route('/api/stats')
    def api_stats():
        return jsonify({
            'guests'    : Guest.query.filter_by(is_active=True).count(),
            'vacant'    : Bed.query.filter_by(is_occupied=False).count(),
            'occupied'  : Bed.query.filter_by(is_occupied=True).count(),
            'complaints': Complaint.query.filter(Complaint.status != 'Resolved').count(),
        })
        